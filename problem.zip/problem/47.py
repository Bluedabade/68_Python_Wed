def calculate_rectangle_area(width,length):
    return width * length

width = 5
length = 10

print(calculate_rectangle_area(width,length))