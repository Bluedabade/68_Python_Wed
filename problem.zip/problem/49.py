def toggle_case(s: str) -> str:
    return s.swapcase()


s = "Hello World!"

print(toggle_case(s))