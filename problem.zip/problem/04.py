num_1 = float(input("Enter number 1 :"))
num_2 = float(input("Enter number 2 :"))
num_3 = float(input("Enter number 3 :"))
num_4 = float(input("Enter number 4 :"))
num_5 = float(input("Enter number 5 :"))
sum = (num_1 + num_2 + num_3 + num_4 + num_5)
avg =  sum / 5
print("Average: ", avg)
print("Sum: ", sum)