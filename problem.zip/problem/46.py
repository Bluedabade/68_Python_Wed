def calculate_perimeter(a, b, c):
    return(a+b+c)

a = 3
b = 4
c = 5

print(calculate_perimeter(a, b, c))